#include "BVHTree.h"

using namespace std;




BVHTree:: BVHTree()
{
	root = NULL;
}


BVHTree:: ~BVHTree()
{
	makeEmpty(root);
}

void BVHTree:: makeEmpty(BVHTreeNode* ptr)
{
	while (root != NULL)
	{
		makeEmpty(root->leftChild);
		makeEmpty(root->rightChild);
		delete root;
	}
}

void BVHTree::addBVHMember(AABB objectArea, std::string name)
{

	if (root == NULL) // no node in the map
	{
		root = new BVHTreeNode(objectArea,name,true); // for now it is leaf
		map[name] = root;
	}
	else if (root != NULL && root->leftChild == NULL && root->rightChild == NULL) // meaning that there is only one node
	{
		BVHTreeNode* ptr;
		BVHTreeNode* fornew;
		AABB bigger_one = objectArea + root->aabb;
		fornew = new BVHTreeNode(objectArea, name, true); // adding new one as a leaf
		ptr = new BVHTreeNode(bigger_one,"branch", false); // it is going to be a root, so isLeaf should be false
		ptr->rightChild = root; // right child must be the oldest root 
		ptr->leftChild = fornew; // left child must be the new one
		fornew->parent = ptr;
		root->parent = ptr;
		root = ptr; // now our root is ptr
		map[name] = fornew;
	}
	else
	{
		// first let's find the leaf that we will use
		BVHTreeNode* pint;
		pint = root;
		int increaseInRightTreeSize;
		int increaseInLeftTreeSize;
		string last_move = "";
		while (pint->rightChild != NULL && pint->leftChild != NULL)
		{

			increaseInRightTreeSize = AABB::unionArea(objectArea,pint->rightChild->aabb) - pint->rightChild->aabb.getArea();
			increaseInLeftTreeSize = AABB::unionArea(objectArea, pint->leftChild->aabb) - pint->leftChild->aabb.getArea();
			if (increaseInRightTreeSize < increaseInLeftTreeSize)
			{
				pint = pint->rightChild;
				last_move = "right";
			}
			else
			{
				pint = pint->leftChild;
				last_move = "left";
			}
		} // after that loop pint points to the leaf we will use

		AABB big_one = pint->aabb + objectArea;
		BVHTreeNode* ptr;
		BVHTreeNode* showing_new;
		showing_new = new BVHTreeNode(objectArea, name, true); // adding new one as a leaf
		ptr = new BVHTreeNode(big_one, "branch", false);
		ptr->rightChild = pint; // right one shows the existing leaf
		ptr->leftChild = showing_new; // left child shows the new one to be added
		
		if (last_move == "right")
		{
			pint->parent->rightChild = ptr;
			ptr->parent = pint->parent;
		}
		else
		{
			pint->parent->leftChild = ptr;
			ptr->parent = pint->parent;
		}
		pint->parent = ptr;
		showing_new->parent = ptr;
		map[name] = showing_new;
		BVHTreeNode* check = pint; // pint is the existingLeaf
		while (pint->parent != NULL)
		{
			pint->parent->aabb = pint->parent->leftChild->aabb + pint->parent->rightChild->aabb;
			pint = pint->parent;
		}
		

	}


}

void BVHTree::moveBVHMember(std::string name, AABB newLocation)
{
	BVHTreeNode* ptr = map[name];
	BVHTreeNode* forparent = ptr->parent;
	if (newLocation.maxX > forparent->aabb.maxX || newLocation.maxY > forparent->aabb.maxY || newLocation.minX < forparent->aabb.minX || newLocation.minY < forparent->aabb.minY)
	{
		removeBVHMember(name);
		addBVHMember(newLocation, name);
	}
	else
		ptr->aabb = newLocation;


}

void BVHTree:: removeBVHMember(std::string name)
{
	BVHTreeNode* tobedeleted = map[name];
	
	string direction = "";


	if (tobedeleted == root) // neaning that there is only one node in the tree
	{
		delete root;
	}

	else if (tobedeleted->parent == root)
	{
		map.erase(tobedeleted->name);
		if (tobedeleted->name == tobedeleted->parent->leftChild->name) // if the node is in the left of parent
		{
			root = tobedeleted ->parent->rightChild;
			root->parent = NULL;
			root->leftChild = NULL;
			root->rightChild = NULL;
			delete tobedeleted;
		}
		else if (tobedeleted->name == tobedeleted->parent->rightChild->name) // if the node is in the left of parent
		{
			root = tobedeleted->parent->leftChild;
			root->parent = NULL;
			root->leftChild = NULL;
			root->rightChild = NULL;
			delete tobedeleted;
		}
	}


	else if (tobedeleted != root && tobedeleted ->parent != root ) 
	{
		map.erase(tobedeleted->name);
		BVHTreeNode* previous = tobedeleted->parent;
		if (previous->parent->leftChild == previous) // if parent is the left child of the grandparent
			direction = "left";
		else if (previous->parent->rightChild == previous) // if parent is the right child of the grandparent
			direction = "right";


		// creating second direction to find the sibling of the node to be deleted
		string direction_sibling = "";
		if (previous->leftChild->name == name)
			direction_sibling = "left";
		else if (previous->rightChild->name == name)
			direction_sibling = "right";

		string x = "a"; // just to write a random statement between two if conditions



		if (direction == "left")
		{
			if (direction_sibling == "right")
			{
				BVHTreeNode* grandparent = previous->parent;
				grandparent->leftChild= previous->leftChild; 
				previous->leftChild->parent = grandparent;
				previous->leftChild = NULL;
				delete previous;
			}
			else if (direction_sibling == "left")
			{
				BVHTreeNode* grandparent = previous->parent;
				grandparent->leftChild = previous->rightChild;
				previous->rightChild->parent = grandparent;
				previous->rightChild = NULL;
				delete previous;
			}
		}
		else if (direction == "right")
		{
			if (direction_sibling == "right")
			{
				BVHTreeNode* grandparent = previous->parent;
				grandparent->rightChild = previous->leftChild;
				previous->leftChild->parent = grandparent;
				previous->leftChild = NULL;
				delete previous;
			}
			else if (direction_sibling == "left")
			{
				BVHTreeNode* grandparent = previous->parent;
				grandparent->rightChild = previous->rightChild;
				previous->rightChild->parent = grandparent;
				previous->rightChild = NULL;
				delete previous;
			}
		}

	}






}



std::vector<std::string> BVHTree::getCollidingObjects(AABB object)
{
	vector<string> collision;
	if(root != NULL)
	   Collide(root, object, collision);

	return collision;
	
}

void BVHTree::Collide(BVHTreeNode* ptr, AABB& object, vector<string>& a)
{
	if ( ptr->aabb.collide(object))
	{
		if (ptr->isLeaf == false)
		{
			Collide(ptr->leftChild, object, a);
			Collide(ptr->rightChild, object, a);
		}	

	}
	if (ptr->aabb.collide(object))
	{
		if(ptr->isLeaf == true)
		   a.push_back(ptr->name);
	}
      	
}



















void BVHTree::printNode(std::ostream &out, BVHTreeNode *node, int level) {
	if (root == nullptr) return;
	for (int i = 0; i < level; i++) {
		out << "  ";
	}
	if (!node->isLeaf) {
		out << "+ branch || ";
		node->aabb.printAABB(out);
		out << std::endl;
		printNode(out, node->rightChild, level + 1);
		printNode(out, node->leftChild, level + 1);
	}
	else {
		out << "- ";
		if (node->parent) {
			if (node->parent->rightChild == node)
				out << "R ";
			else
				out << "L ";
		}
		out << "- leaf: " << node->name << " || ";
		node->aabb.printAABB(out);
		out << std::endl;
	}
}
std::ostream &operator<<(std::ostream &out, BVHTree &tree) {
	tree.printNode(out, tree.root, 0);
	return out;
}